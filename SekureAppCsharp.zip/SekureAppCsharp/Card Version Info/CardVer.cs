using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using SekureAppCsharp.Utility;


namespace SekureAppCsharp.Card_Version_Info
{
	/// <summary>
	/// Summary description for CardVer.
	/// </summary>
	public class frmCrdVer : System.Windows.Forms.Form
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;
		private System.Windows.Forms.TextBox txtCrdVersion;
		private System.Windows.Forms.TextBox txtIssueDate;
		private System.Windows.Forms.TextBox txtOtherID;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label3;
		private SekureClass.IDCARDINFO cardInfo;

		public frmCrdVer(SekureClass.IDCARDINFO cardInfo)
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//

			this.cardInfo=cardInfo;

			

		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.txtCrdVersion = new System.Windows.Forms.TextBox();
			this.txtIssueDate = new System.Windows.Forms.TextBox();
			this.txtOtherID = new System.Windows.Forms.TextBox();
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.SuspendLayout();
			// 
			// txtCrdVersion
			// 
			this.txtCrdVersion.Location = new System.Drawing.Point(136, 64);
			this.txtCrdVersion.Name = "txtCrdVersion";
			this.txtCrdVersion.ReadOnly = true;
			this.txtCrdVersion.TabIndex = 0;
			this.txtCrdVersion.Text = "";
			// 
			// txtIssueDate
			// 
			this.txtIssueDate.Location = new System.Drawing.Point(136, 128);
			this.txtIssueDate.Name = "txtIssueDate";
			this.txtIssueDate.ReadOnly = true;
			this.txtIssueDate.TabIndex = 1;
			this.txtIssueDate.Text = "";
			// 
			// txtOtherID
			// 
			this.txtOtherID.Location = new System.Drawing.Point(136, 96);
			this.txtOtherID.Name = "txtOtherID";
			this.txtOtherID.ReadOnly = true;
			this.txtOtherID.TabIndex = 2;
			this.txtOtherID.Text = "";
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(56, 64);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(72, 23);
			this.label1.TabIndex = 3;
			this.label1.Text = "Card Ver:";
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(56, 96);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(72, 23);
			this.label2.TabIndex = 4;
			this.label2.Text = "Other ID:";
			// 
			// label3
			// 
			this.label3.Location = new System.Drawing.Point(56, 128);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(72, 23);
			this.label3.TabIndex = 5;
			this.label3.Text = "Issue Date:";
			// 
			// frmCrdVer
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(292, 266);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.txtOtherID);
			this.Controls.Add(this.txtIssueDate);
			this.Controls.Add(this.txtCrdVersion);
			this.Name = "frmCrdVer";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Card Version";
			this.Load += new System.EventHandler(this.frmCrdVer_Load);
			this.ResumeLayout(false);

		}
		#endregion

		
		private void frmCrdVer_Load(object sender, System.EventArgs e)
		{
			

			this.txtCrdVersion.Text=this.cardInfo.szCardVer_No.Trim();
			this.txtOtherID.Text=this.cardInfo.szOther_ID.Trim();
			this.txtIssueDate.Text=this.cardInfo. szIssueDate.Trim();
		}

		
	}
}
