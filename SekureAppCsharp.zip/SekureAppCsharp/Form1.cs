using System;
using System.IO;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using SekureAppCsharp.IMM_Info;
using SekureAppCsharp.JPJ_Info;
using SekureAppCsharp.JPN_Info;
using SekureAppCsharp.MEPS_Info;
using SekureAppCsharp.Card_Version_Info;
using SekureAppCsharp.Utility;
using System.Runtime.InteropServices;
using System.Threading;


namespace SekureAppCsharp
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Button btnJPN;
		private System.Windows.Forms.Button btnJPJ;
		private System.Windows.Forms.Button btnIMM;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Button btnMEPS;
		private System.Windows.Forms.Button btnInit;
		private System.Windows.Forms.Button btnClose;
		private short comPort;
		private bool isDeviceInit;
		private SekureClass.JPNCARDINFO jpnCardInfo;
		private SekureClass.PHOTOIMAGE photoImg;
		private SekureClass.JPJCARDINFO jpjCardInfo;
		private SekureClass.IDCARDINFO idInfo;
		private SekureClass.VERIFICATIONRESULT verResult;
		private SekureClass.MEPSINFO mepsInfo;
		private SekureClass.IMMCARDINFO immInfo;
		private SekureClass.BIOMETRICDATA bioData;
		private System.Windows.Forms.TextBox txtComport;
		private System.Windows.Forms.Label lblStatus;
		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.Button btnCardVer;
		private System.Windows.Forms.Button btnFingerVer;
		private System.Windows.Forms.Timer bioTimer;
		private System.Windows.Forms.Timer DtcCardtimer;
		private System.Windows.Forms.Label lblCardStatus;
        private PictureBox picImage;
        private Button ConvertToBMP;
        private Label label2;
        private TextBox LicenseKey;
        private Label label3;
        private Button Verify;
        private TextBox DepPath;
        private Button btnDisableFingerImage;
        private Button btnEnableFingerImage;
		private System.ComponentModel.IContainer components;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
			
			isDeviceInit=false;

		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            this.components = new System.ComponentModel.Container();
            this.btnJPN = new System.Windows.Forms.Button();
            this.btnJPJ = new System.Windows.Forms.Button();
            this.btnCardVer = new System.Windows.Forms.Button();
            this.btnIMM = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.txtComport = new System.Windows.Forms.TextBox();
            this.btnInit = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            this.btnMEPS = new System.Windows.Forms.Button();
            this.lblStatus = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lblCardStatus = new System.Windows.Forms.Label();
            this.btnFingerVer = new System.Windows.Forms.Button();
            this.bioTimer = new System.Windows.Forms.Timer(this.components);
            this.DtcCardtimer = new System.Windows.Forms.Timer(this.components);
            this.picImage = new System.Windows.Forms.PictureBox();
            this.ConvertToBMP = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.LicenseKey = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.Verify = new System.Windows.Forms.Button();
            this.DepPath = new System.Windows.Forms.TextBox();
            this.btnDisableFingerImage = new System.Windows.Forms.Button();
            this.btnEnableFingerImage = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picImage)).BeginInit();
            this.SuspendLayout();
            // 
            // btnJPN
            // 
            this.btnJPN.Location = new System.Drawing.Point(43, 153);
            this.btnJPN.Name = "btnJPN";
            this.btnJPN.Size = new System.Drawing.Size(88, 40);
            this.btnJPN.TabIndex = 0;
            this.btnJPN.Text = "JPN Info";
            this.btnJPN.Click += new System.EventHandler(this.btnJPN_Click);
            // 
            // btnJPJ
            // 
            this.btnJPJ.Location = new System.Drawing.Point(43, 209);
            this.btnJPJ.Name = "btnJPJ";
            this.btnJPJ.Size = new System.Drawing.Size(88, 40);
            this.btnJPJ.TabIndex = 1;
            this.btnJPJ.Text = "JPJ Info";
            this.btnJPJ.Click += new System.EventHandler(this.btnJPJ_Click);
            // 
            // btnCardVer
            // 
            this.btnCardVer.Location = new System.Drawing.Point(43, 265);
            this.btnCardVer.Name = "btnCardVer";
            this.btnCardVer.Size = new System.Drawing.Size(88, 40);
            this.btnCardVer.TabIndex = 2;
            this.btnCardVer.Text = "Card Version Info";
            this.btnCardVer.Click += new System.EventHandler(this.btnCardVer_Click);
            // 
            // btnIMM
            // 
            this.btnIMM.Location = new System.Drawing.Point(147, 153);
            this.btnIMM.Name = "btnIMM";
            this.btnIMM.Size = new System.Drawing.Size(88, 40);
            this.btnIMM.TabIndex = 3;
            this.btnIMM.Text = "IMM Info";
            this.btnIMM.Click += new System.EventHandler(this.btnIMM_Click);
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(50, 83);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(56, 16);
            this.label1.TabIndex = 4;
            this.label1.Text = "Com Port:";
            // 
            // txtComport
            // 
            this.txtComport.Location = new System.Drawing.Point(114, 83);
            this.txtComport.Name = "txtComport";
            this.txtComport.Size = new System.Drawing.Size(68, 20);
            this.txtComport.TabIndex = 5;
            this.txtComport.Text = "2";
            // 
            // btnInit
            // 
            this.btnInit.Location = new System.Drawing.Point(188, 81);
            this.btnInit.Name = "btnInit";
            this.btnInit.Size = new System.Drawing.Size(86, 23);
            this.btnInit.TabIndex = 6;
            this.btnInit.Text = "init";
            this.btnInit.Click += new System.EventHandler(this.btnInit_Click);
            // 
            // btnClose
            // 
            this.btnClose.Location = new System.Drawing.Point(290, 83);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(96, 23);
            this.btnClose.TabIndex = 7;
            this.btnClose.Text = "Close";
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // btnMEPS
            // 
            this.btnMEPS.Location = new System.Drawing.Point(147, 209);
            this.btnMEPS.Name = "btnMEPS";
            this.btnMEPS.Size = new System.Drawing.Size(88, 40);
            this.btnMEPS.TabIndex = 8;
            this.btnMEPS.Text = "MEPS Info";
            this.btnMEPS.Click += new System.EventHandler(this.btnMEPS_Click);
            // 
            // lblStatus
            // 
            this.lblStatus.Location = new System.Drawing.Point(8, 24);
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.Size = new System.Drawing.Size(366, 24);
            this.lblStatus.TabIndex = 9;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.lblStatus);
            this.groupBox1.Controls.Add(this.lblCardStatus);
            this.groupBox1.Location = new System.Drawing.Point(24, 391);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(412, 56);
            this.groupBox1.TabIndex = 10;
            this.groupBox1.TabStop = false;
            // 
            // lblCardStatus
            // 
            this.lblCardStatus.Location = new System.Drawing.Point(12, 25);
            this.lblCardStatus.Name = "lblCardStatus";
            this.lblCardStatus.Size = new System.Drawing.Size(240, 23);
            this.lblCardStatus.TabIndex = 12;
            // 
            // btnFingerVer
            // 
            this.btnFingerVer.Location = new System.Drawing.Point(147, 265);
            this.btnFingerVer.Name = "btnFingerVer";
            this.btnFingerVer.Size = new System.Drawing.Size(88, 40);
            this.btnFingerVer.TabIndex = 11;
            this.btnFingerVer.Text = "Finger Verify";
            this.btnFingerVer.Click += new System.EventHandler(this.btnFingerVer_Click);
            // 
            // bioTimer
            // 
            this.bioTimer.Tick += new System.EventHandler(this.bioTimer_Tick);
            // 
            // DtcCardtimer
            // 
            this.DtcCardtimer.Tick += new System.EventHandler(this.DtcCardtimer_Tick);
            // 
            // picImage
            // 
            this.picImage.Location = new System.Drawing.Point(281, 153);
            this.picImage.Name = "picImage";
            this.picImage.Size = new System.Drawing.Size(115, 154);
            this.picImage.TabIndex = 13;
            this.picImage.TabStop = false;
            // 
            // ConvertToBMP
            // 
            this.ConvertToBMP.Location = new System.Drawing.Point(43, 311);
            this.ConvertToBMP.Name = "ConvertToBMP";
            this.ConvertToBMP.Size = new System.Drawing.Size(192, 34);
            this.ConvertToBMP.TabIndex = 14;
            this.ConvertToBMP.Text = "Convert RAW Image To BMP";
            this.ConvertToBMP.UseVisualStyleBackColor = true;
            this.ConvertToBMP.Click += new System.EventHandler(this.ConvertToBMP_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(40, 56);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(65, 13);
            this.label2.TabIndex = 15;
            this.label2.Text = "License Key";
            // 
            // LicenseKey
            // 
            this.LicenseKey.Location = new System.Drawing.Point(116, 49);
            this.LicenseKey.Name = "LicenseKey";
            this.LicenseKey.Size = new System.Drawing.Size(180, 20);
            this.LicenseKey.TabIndex = 16;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(21, 18);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(85, 13);
            this.label3.TabIndex = 17;
            this.label3.Text = "Dependent Path";
            // 
            // Verify
            // 
            this.Verify.Location = new System.Drawing.Point(302, 49);
            this.Verify.Name = "Verify";
            this.Verify.Size = new System.Drawing.Size(84, 23);
            this.Verify.TabIndex = 18;
            this.Verify.Text = "Verify License";
            this.Verify.UseVisualStyleBackColor = true;
            this.Verify.Click += new System.EventHandler(this.Verify_Click);
            // 
            // DepPath
            // 
            this.DepPath.Location = new System.Drawing.Point(116, 18);
            this.DepPath.Name = "DepPath";
            this.DepPath.Size = new System.Drawing.Size(180, 20);
            this.DepPath.TabIndex = 19;
            // 
            // btnDisableFingerImage
            // 
            this.btnDisableFingerImage.Location = new System.Drawing.Point(43, 351);
            this.btnDisableFingerImage.Name = "btnDisableFingerImage";
            this.btnDisableFingerImage.Size = new System.Drawing.Size(192, 34);
            this.btnDisableFingerImage.TabIndex = 20;
            this.btnDisableFingerImage.Text = "Disable Finger Image";
            this.btnDisableFingerImage.UseVisualStyleBackColor = true;
            this.btnDisableFingerImage.Click += new System.EventHandler(this.btnDisableFingerImage_Click);
            // 
            // btnEnableFingerImage
            // 
            this.btnEnableFingerImage.Location = new System.Drawing.Point(241, 351);
            this.btnEnableFingerImage.Name = "btnEnableFingerImage";
            this.btnEnableFingerImage.Size = new System.Drawing.Size(192, 34);
            this.btnEnableFingerImage.TabIndex = 21;
            this.btnEnableFingerImage.Text = "Enable Finger Image";
            this.btnEnableFingerImage.UseVisualStyleBackColor = true;
            this.btnEnableFingerImage.Click += new System.EventHandler(this.btnEnableFingerImage_Click);
            // 
            // Form1
            // 
            this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
            this.ClientSize = new System.Drawing.Size(451, 458);
            this.Controls.Add(this.btnEnableFingerImage);
            this.Controls.Add(this.btnDisableFingerImage);
            this.Controls.Add(this.DepPath);
            this.Controls.Add(this.Verify);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.LicenseKey);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.ConvertToBMP);
            this.Controls.Add(this.picImage);
            this.Controls.Add(this.btnFingerVer);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btnMEPS);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.btnInit);
            this.Controls.Add(this.txtComport);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnIMM);
            this.Controls.Add(this.btnCardVer);
            this.Controls.Add(this.btnJPJ);
            this.Controls.Add(this.btnJPN);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.picImage)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		private void btnJPN_Click(object sender, System.EventArgs e)
		{
			int nRet;
			FileStream fs;
			this.DtcCardtimer.Stop();
			Thread.Sleep(100);
			
			
			
			
			

			if (SekureClass.SCRResetCT(this.comPort)==0)
			{
				if (SekureClass.SCRResetCard(comPort)==0)
				{

					this.setLblText("Retrieving JPN card info...");

					nRet=SekureClass.SCRGetJPNCardInfo(comPort,  ref jpnCardInfo);

					if (nRet==1)
					{
						this.setLblText("Fail to retrieve JPN card info status " + nRet.ToString());
						return;
					}
					SekureClass.SCRGetPhotoImage(comPort,ref this.photoImg);
					fs = new FileStream("C:\\aPhoto.jpg",FileMode.Create);
					
					fs.Write(this.photoImg.pImage,0,photoImg.nSize);
					fs.Close();
					
					frmJpnInfo frmJpn=new frmJpnInfo(jpnCardInfo);
					

					
					frmJpn.ShowDialog();
					
					
				}
			}
				
			
			

			
			this.showLblStatus(this.isDeviceInit);
			this.DtcCardtimer.Start();

		}

		private void btnJPJ_Click(object sender, System.EventArgs e)
		{
			int nRet;
				
			
			this.DtcCardtimer.Stop();
			Thread.Sleep(100);

			if (SekureClass.SCRResetCT(comPort)!=0)
			{
				this.setLblText("Fail to reset terminal");
				return;
			}

			if (SekureClass.SCRResetCard(comPort)==0)
			{
				
				this.setLblText("Retrieving JPJ card info...");

				nRet=SekureClass.SCRGetJPJCardInfo(comPort,  ref this.jpjCardInfo);
				
				if (nRet==0)
				{
					frmJpjInfo frmJpj=new frmJpjInfo(this.jpjCardInfo);
					
					frmJpj.ShowDialog();
				}
				else
				{
					this.setLblText("Retrieving jpj info status " + nRet.ToString());
					Thread.Sleep(2000);
				}
					
				
			}
			
			this.showLblStatus(this.isDeviceInit);
			this.DtcCardtimer.Start();
		}

		private void btnInit_Click(object sender, System.EventArgs e)
		{
			int nRet;
			
			this.comPort=short.Parse(this.txtComport.Text);
			
			SekureClass.SCRClose(this.comPort);

			nRet=SekureClass.SCRInit(this.comPort);
			if (nRet==0)
			{
				if (SekureClass.SCRResetCT(this.comPort)==0)
				{
					this.isDeviceInit=true;
					this.showLblStatus(this.isDeviceInit);
					this.setControlEnable(this.isDeviceInit);
					this.DtcCardtimer.Start();	
				}
			}
			

		}

		private void btnClose_Click(object sender, System.EventArgs e)
		{
			int nRet;
			this.DtcCardtimer.Stop();
			nRet=SekureClass.SCRClose(this.comPort);
			if (nRet==0)
			{
				this.isDeviceInit=false;
				this.showLblStatus(this.isDeviceInit);
				this.setControlEnable(this.isDeviceInit);
			}
		}

		

		private void Form1_Load(object sender, System.EventArgs e)
		{
			this.showLblStatus(this.isDeviceInit);
			this.setControlEnable(this.isDeviceInit);
		}

		private void btnCardVer_Click(object sender, System.EventArgs e)
		{
			int nRet;

			
			this.DtcCardtimer.Stop();

			if (SekureClass.SCRResetCT(comPort)!=0)
			{
				this.setLblText("Fail to reset terminal");
				return;
			}

			if (SekureClass.SCRResetCard(comPort)==0)
			{
				

				this.setLblText("Retrieving ID card info...");

				nRet=SekureClass.SCRGetIdCardInfo(comPort,  ref this.idInfo);
				
					
				frmCrdVer frmVer=new frmCrdVer(this.idInfo);
				
				frmVer.ShowDialog();
					
				
			}

			this.showLblStatus(this.isDeviceInit);
			this.DtcCardtimer.Start();
		
		}

		private void showLblStatus(bool isDeviceInitialise)
		{
			if (!isDeviceInitialise)
			{
				this.lblStatus.Text="Device not Ready";
				this.Update();
			}
			else
			{
				this.lblStatus.Text="Device Ready";
				this.Update();
			}
		}

		private void setLblText(string strMsg)
		{
			this.lblStatus.Text=strMsg;
			this.Update();
		}

		private void setLblText2(string strMsg)
		{
			this.lblCardStatus.Text=strMsg;
			this.Update();
		}

		private void btnFingerVer_Click(object sender, System.EventArgs e)
		{
			int nRet;
            this.picImage.Image = null;
			/****************************Bio Termination*****************************/			
			if (this.btnFingerVer.Text.Equals("Terminate Bio"))
			{
				if (this.terminateBioProcess())
				{
					this.bioTimer.Stop();
					this.setLblText("Bio process successfully terminated");
					Thread.Sleep(2000);					
					this.DtcCardtimer.Start();
				}
				else
				{
					this.setLblText("Fail to terminate Bio Process");
					Thread.Sleep(2000);
				}
				return;
			}
			/****************************Ends here*****************************/
			
			this.DtcCardtimer.Stop();

			if (SekureClass.SCRResetCT(comPort)!=0)
			{
				this.setLblText("Fail to reset terminal");
				return;
			}

			SekureClass.SCRResetCard(this.comPort);
			
			this.setLblText("Retrieving Minutiae...");
			nRet=SekureClass.SCRGetMinutiae(this.comPort,ref this.bioData);
			if (nRet==0)
			{

				if (SekureClass.SCRVerifyBioCB(this.comPort)==0)
				{
					bioTimer.Start();
					this.btnFingerVer.Text="Terminate Bio";
					this.Update();
				}
			}
			else
				this.setLblText("Get Minutiae status is " + nRet.ToString());


		}

		private bool terminateBioProcess()
		{
			if (SekureClass.SCRTerminateBio(this.comPort)==0)
				return true;
			else
				return false;
		}

		private void setControlEnable(bool isControlEnabled)
		{
			this.btnCardVer.Enabled=isControlEnabled;
			this.btnJPN.Enabled=isControlEnabled;
			this.btnJPJ.Enabled=isControlEnabled;
			this.btnMEPS.Enabled=isControlEnabled;
			this.btnIMM.Enabled=isControlEnabled;
			this.btnFingerVer.Enabled=isControlEnabled;
            this.ConvertToBMP.Enabled = isControlEnabled;
            this.btnDisableFingerImage.Enabled = isControlEnabled;
            this.btnEnableFingerImage.Enabled = isControlEnabled;

		}

		private void bioTimer_Tick(object sender, System.EventArgs e)
		{
			bool isEnable=false;
			
			
			this.bioTimer.Stop();
            this.verResult.nRow = 0;
            this.verResult.nCol = 0;
			SekureClass.SCRVerifyBioStatusCB(ref this.verResult);
			

			switch(this.verResult.nFingerStatus)
			{
			case SekureClass.BSP_FINGER_OK:
					this.setLblText("Verifying finger...");
					
					break;
				case SekureClass.BSP_MOVE_DOWN:
					this.setLblText("Move finger down");
					break;
				case SekureClass.BSP_MOVE_LEFT:
					this.setLblText("Move finger left");
					break;
				case SekureClass.BSP_MOVE_PRESS_HARDER:
					this.setLblText("press finger harder");
					break;
				case SekureClass.BSP_MOVE_RIGHT:
					this.setLblText("Move finger right");
					break;
				case SekureClass.BSP_MOVE_UP:
					this.setLblText("Move finger up");
					break;
				case SekureClass.BSP_NO_FINGER:
					this.setLblText("Please place finger on bio reader");
					break;
				
			}
            if ((this.verResult.nRow * this.verResult.nCol) > 0)
            {
                int nRet;
                nRet = SekureClass.SCRDrawFingerImage(picImage.Handle,this.verResult.nRow , this.verResult.nCol , ref this.verResult.pImage[0]);
            }

			switch(this.verResult.nProcessStatus)
			{
				case SekureClass.BIO_VERIFY_FAILED:
				case SekureClass.BIO_MATCH_FAILED:
					isEnable=false;
				
					this.setLblText("Finger print not match. Verification process end");
					
					break;
				case SekureClass.BIO_CAPTURE_FAILED:
					isEnable=false;
					
					this.setLblText2("Minutiae capture fail; Please clean the sensor. Verification process end");
					
					break;
				case SekureClass.BIO_MATCH_OK:
					isEnable=false;
					/**** check whether right finger or left finger in finger status****/
					this.setLblText("Finger print MATCH!!!  Verification process end");
					break;
				case SekureClass.BIO_INIT_FAILED:
				case SekureClass.READER_FAILED:
				case SekureClass.BSP_RET_NO_DEVICE:
					isEnable=false;
					this.setLblText("Unable to initialise biometric device");
					break;

				case SekureClass.BIO_PROCESS_FAILED_SCR_INIT_FAILED:
				case SekureClass.BIO_VERIFY_FAILED_SCR_INIT_FAILED:		
				case SekureClass.BIO_MATCH_FAILED_SCR_INIT_FAILED:		
				case SekureClass.BIO_CAPTURE_FAILED_SCR_INIT_FAILED:			
				case SekureClass.BIO_MATCH_OK_SCR_INIT_FAILED:	
					//Biometric verification process fail
					//And unable to initialise smart card reader
					//Possiblity is during the verification process
					//USB/Serial/Power plugged out.
					isEnable=false;
					this.setLblText("Fail to initialise biometric and smart card reader");
					break;
				case SekureClass.BIO_INIT_FAILED_SCR_INIT_FAILED:
					//Unable to initialise biometric device
					//Unable to initialise smart card reader
					//Possibility is no sekure device found
					//Another possibility is no power to the sekure device
					//Another possibitity the USB/Serial cable is plugged in
					//Another possibitity the port number is invalid
					isEnable=false;
					this.setLblText("Fail to initialise biometric and smart card reader");
					break;
				default:
					isEnable=true;
					break;
			}



			

		


			if (isEnable)
				this.bioTimer.Start();
			else
			{
				this.btnFingerVer.Text="Verify Fingerprint";
				this.Update();
				Thread.Sleep(2000);	
				this.DtcCardtimer.Start();
			}
			
		}

		private void verStatus(short intRes)
		{
			switch(intRes)
			{
			case SekureClass.BSP_FINGER_OK:
				this.setLblText("Verifying finger...");
				
				break;
			case SekureClass.BSP_MOVE_DOWN:
				this.setLblText("Move finger down");
				break;
			case SekureClass.BSP_MOVE_LEFT:
				this.setLblText("Move finger left");
				break;
			case SekureClass.BSP_MOVE_PRESS_HARDER:
				this.setLblText("press finger harder");
				break;
			case SekureClass.BSP_MOVE_RIGHT:
				this.setLblText("Move finger right");
				break;
			case SekureClass.BSP_MOVE_UP:
				this.setLblText("Move finger up");
				break;
			case SekureClass.BSP_NO_FINGER:
				this.setLblText("Please place finger on bio reader");
				break;
				
			}
			
			
		}

		private void btnMEPS_Click(object sender, System.EventArgs e)
		{
			this.DtcCardtimer.Stop();
			Thread.Sleep(100);
			

			if (SekureClass.SCRResetCT(comPort)!=0)
			{
				this.setLblText("Fail to reset terminal");
				return;
			}
			if (SekureClass.SCRResetCard(comPort)==0)
			{
				

				this.setLblText("Retrieving MEPS Balance info...");

				SekureClass.SCRGetMEPSBalance(comPort,  ref this.mepsInfo);
				
					
				frmMepsInfo frmMeps=new frmMepsInfo(this.mepsInfo);
				
				frmMeps.ShowDialog();
					
				
			}

			this.showLblStatus(this.isDeviceInit);
			this.DtcCardtimer.Start();
		}

		private void btnIMM_Click(object sender, System.EventArgs e)
		{
			int nRet;
			this.DtcCardtimer.Stop();
			Thread.Sleep(100);

			if (SekureClass.SCRResetCT(comPort)!=0)
			{
				this.setLblText("Fail to reset terminal");
				return;
			}

			
			if (SekureClass.SCRResetCard(comPort)==0)
			{
				

				this.setLblText("Retrieving IMM info...");

				nRet=SekureClass.SCRGetIMMInfo(comPort,  ref this.immInfo);
				
					if (nRet!=0)
					{
						this.setLblText("Error in getting card info  Status " + nRet);
						return;
					}
				
					
				frmImmInfo frmIMM=new frmImmInfo(this.immInfo);
				
				frmIMM.ShowDialog();
					
				
			}

			this.showLblStatus(this.isDeviceInit);
			this.DtcCardtimer.Start();
		}

		private void DtcCardtimer_Tick(object sender, System.EventArgs e)
		{
			switch(SekureClass.SCRGetCardStatus(this.comPort))
			{
				case 0:
					this.setLblText("Please insert MyKad");
					break;
				case 1:
					this.setLblText("Card inserted");
					break;
			}
		}

        private void Verify_Click(object sender, EventArgs e)
        {
            int nRet;

            nRet = SekureClass.SCRSetDependentPath(DepPath.Text.ToCharArray() );
            if (nRet == 0)
            {
                nRet = SekureClass.SCRVerifyLicense(LicenseKey.Text.ToCharArray());
                if (nRet != 0)
                {
                    String s;
                    s = String.Format("{0:N}", nRet);
                    MessageBox.Show("License Verification Failed ");
                    MessageBox.Show(s);
                }
                else
                    MessageBox.Show("License Verification Success");
            }
            else
            {
                MessageBox.Show ("Set Dependent Path Failed");
            }

        }

        private void ConvertToBMP_Click(object sender, EventArgs e)
        {
            int nRet;
            string FilePath;
            FilePath = DepPath.Text + "\\fp.bmp";
            nRet = SekureClass.SCRConvertRAWImageToBMP(this.verResult.nRow, this.verResult.nCol, ref this.verResult.pImage[0], FilePath);


        }

        private void btnDisableFingerImage_Click(object sender, EventArgs e)
        {
            SekureClass.SCRDisableFingerImage(false);
        }

        private void btnEnableFingerImage_Click(object sender, EventArgs e)
        {
            SekureClass.SCRDisableFingerImage(true);
        }

		

		
	}
}
