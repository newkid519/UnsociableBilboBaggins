using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using SekureAppCsharp.Utility;

namespace SekureAppCsharp.IMM_Info
{
	/// <summary>
	/// Summary description for JPJInfo.
	/// </summary>
	
	public class frmImmInfo : System.Windows.Forms.Form
	{
		private SekureClass.IMMCARDINFO immInfo;
		private System.Windows.Forms.ColumnHeader clmPsType;
		private System.Windows.Forms.ColumnHeader clmPsNo;
		private System.Windows.Forms.ColumnHeader clmPsExpDate;
		private System.Windows.Forms.ListView lstPassport;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public frmImmInfo(SekureClass.IMMCARDINFO immInfo)
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//

			this.immInfo=immInfo;
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.lstPassport = new System.Windows.Forms.ListView();
			this.clmPsType = new System.Windows.Forms.ColumnHeader();
			this.clmPsNo = new System.Windows.Forms.ColumnHeader();
			this.clmPsExpDate = new System.Windows.Forms.ColumnHeader();
			this.SuspendLayout();
			// 
			// lstPassport
			// 
			this.lstPassport.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
																						  this.clmPsType,
																						  this.clmPsNo,
																						  this.clmPsExpDate});
			this.lstPassport.Location = new System.Drawing.Point(56, 64);
			this.lstPassport.Name = "lstPassport";
			this.lstPassport.Size = new System.Drawing.Size(464, 136);
			this.lstPassport.TabIndex = 0;
			this.lstPassport.View = System.Windows.Forms.View.Details;
			// 
			// clmPsType
			// 
			this.clmPsType.Text = "Passport Type";
			this.clmPsType.Width = 212;
			// 
			// clmPsNo
			// 
			this.clmPsNo.Text = "Passport Number";
			this.clmPsNo.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			this.clmPsNo.Width = 106;
			// 
			// clmPsExpDate
			// 
			this.clmPsExpDate.Text = "Expiry Date";
			this.clmPsExpDate.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			this.clmPsExpDate.Width = 142;
			// 
			// frmImmInfo
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(576, 266);
			this.Controls.Add(this.lstPassport);
			this.Name = "frmImmInfo";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "IMMInfo";
			this.Load += new System.EventHandler(this.frmImmInfo_Load);
			this.ResumeLayout(false);

		}
		#endregion

		private void frmImmInfo_Load(object sender, System.EventArgs e)
		{
			this.lstPassport.Items.Add("Passport Malaysia Terhad-Brunei");
			this.lstPassport.Items[0].SubItems.Add(this.immInfo.szBPMTDocType.Trim());
			this.lstPassport.Items[0].SubItems.Add(this.immInfo.szBPMTExpDate.Trim());

			this.lstPassport.Items.Add("Passport Malaysia Antarbangsa");
			this.lstPassport.Items[1].SubItems.Add(this.immInfo.szPMADocType.Trim());
			this.lstPassport.Items[1].SubItems.Add(this.immInfo.szPMAExpDate.Trim());

		

			this.lstPassport.Items.Add("Passport Malaysia Terhad-Singapura");
			this.lstPassport.Items[2].SubItems.Add(this.immInfo.szSPMT.Trim());
			this.lstPassport.Items[2].SubItems.Add(this.immInfo.szSPMT.Trim());
		}
	}
}
