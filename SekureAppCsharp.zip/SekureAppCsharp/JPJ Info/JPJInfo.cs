using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using SekureAppCsharp.Utility;


namespace SekureAppCsharp.JPJ_Info
{
	/// <summary>
	/// Summary description for JPJInfo.
	/// </summary>
	public class frmJpjInfo : System.Windows.Forms.Form
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;
		private System.Windows.Forms.ListView lstjpjInfo;
		private System.Windows.Forms.ColumnHeader clmLicType;
		private System.Windows.Forms.ColumnHeader columnHeader1;
		private System.Windows.Forms.ListView listView1;
		private System.Windows.Forms.ColumnHeader ClmExpDate;
		private System.Windows.Forms.ColumnHeader clmStDate;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.TextBox txtOwnerCat;
		private System.Windows.Forms.TextBox txtVehClass;
		private System.Windows.Forms.TextBox txtHRegNo;
		private SekureClass.JPJCARDINFO jpjInfo;

		public frmJpjInfo(SekureClass.JPJCARDINFO jpjInfo)
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
			this.jpjInfo=jpjInfo;

		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Windows.Forms.ListViewItem listViewItem1 = new System.Windows.Forms.ListViewItem("PDL");
			System.Windows.Forms.ListViewItem listViewItem2 = new System.Windows.Forms.ListViewItem("CDL");
			System.Windows.Forms.ListViewItem listViewItem3 = new System.Windows.Forms.ListViewItem("GDL");
			System.Windows.Forms.ListViewItem listViewItem4 = new System.Windows.Forms.ListViewItem("PSV");
			this.lstjpjInfo = new System.Windows.Forms.ListView();
			this.clmLicType = new System.Windows.Forms.ColumnHeader();
			this.columnHeader1 = new System.Windows.Forms.ColumnHeader();
			this.listView1 = new System.Windows.Forms.ListView();
			this.ClmExpDate = new System.Windows.Forms.ColumnHeader();
			this.clmStDate = new System.Windows.Forms.ColumnHeader();
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.txtOwnerCat = new System.Windows.Forms.TextBox();
			this.txtVehClass = new System.Windows.Forms.TextBox();
			this.txtHRegNo = new System.Windows.Forms.TextBox();
			this.SuspendLayout();
			// 
			// lstjpjInfo
			// 
			this.lstjpjInfo.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
																						 this.clmLicType,
																						 this.clmStDate,
																						 this.ClmExpDate});
			this.lstjpjInfo.FullRowSelect = true;
			this.lstjpjInfo.Items.AddRange(new System.Windows.Forms.ListViewItem[] {
																					   listViewItem1,
																					   listViewItem2,
																					   listViewItem3,
																					   listViewItem4});
			this.lstjpjInfo.Location = new System.Drawing.Point(24, 136);
			this.lstjpjInfo.Name = "lstjpjInfo";
			this.lstjpjInfo.Scrollable = false;
			this.lstjpjInfo.Size = new System.Drawing.Size(304, 80);
			this.lstjpjInfo.TabIndex = 0;
			this.lstjpjInfo.View = System.Windows.Forms.View.Details;
			// 
			// clmLicType
			// 
			this.clmLicType.Text = "Licence Type";
			this.clmLicType.Width = 83;
			// 
			// columnHeader1
			// 
			this.columnHeader1.Text = "Expiry Date";
			// 
			// listView1
			// 
			this.listView1.Location = new System.Drawing.Point(0, 0);
			this.listView1.Name = "listView1";
			this.listView1.TabIndex = 0;
			// 
			// ClmExpDate
			// 
			this.ClmExpDate.Text = "Expiry Date";
			this.ClmExpDate.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			this.ClmExpDate.Width = 121;
			// 
			// clmStDate
			// 
			this.clmStDate.Text = "Start Date";
			this.clmStDate.Width = 93;
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(24, 24);
			this.label1.Name = "label1";
			this.label1.TabIndex = 1;
			this.label1.Text = "Owner Category";
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(24, 56);
			this.label2.Name = "label2";
			this.label2.TabIndex = 2;
			this.label2.Text = "Vehicle class";
			// 
			// label3
			// 
			this.label3.Location = new System.Drawing.Point(24, 96);
			this.label3.Name = "label3";
			this.label3.TabIndex = 3;
			this.label3.Text = "Handicap Reg No:";
			// 
			// txtOwnerCat
			// 
			this.txtOwnerCat.Location = new System.Drawing.Point(144, 24);
			this.txtOwnerCat.Name = "txtOwnerCat";
			this.txtOwnerCat.TabIndex = 4;
			this.txtOwnerCat.Text = "";
			// 
			// txtVehClass
			// 
			this.txtVehClass.Location = new System.Drawing.Point(144, 56);
			this.txtVehClass.Name = "txtVehClass";
			this.txtVehClass.TabIndex = 5;
			this.txtVehClass.Text = "";
			// 
			// txtHRegNo
			// 
			this.txtHRegNo.Location = new System.Drawing.Point(144, 96);
			this.txtHRegNo.Name = "txtHRegNo";
			this.txtHRegNo.TabIndex = 6;
			this.txtHRegNo.Text = "";
			// 
			// frmJpjInfo
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(360, 246);
			this.Controls.Add(this.txtHRegNo);
			this.Controls.Add(this.txtVehClass);
			this.Controls.Add(this.txtOwnerCat);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.lstjpjInfo);
			this.Name = "frmJpjInfo";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "JPJInfo";
			this.Load += new System.EventHandler(this.frmJpjInfo_Load);
			this.ResumeLayout(false);

		}
		#endregion

		private void frmJpjInfo_Load(object sender, System.EventArgs e)
		{
			/*
			this.txtCdlDate.Text= this.jpjInfo.szVehicleClass.Trim();
			this.txtLicType.Text=this.jpjInfo.szCELicenceType.Trim();
			this.txtRegNo.Text=this.jpjInfo.szHandiRegNo.Trim();
			this.txtRemarks.Text=this.jpjInfo.szCERemarks.Trim();
*/
			this.lstjpjInfo.Items[0].SubItems.Add(this.jpjInfo.szPDLDate.Substring(0,10).Trim());
			this.lstjpjInfo.Items[0].SubItems.Add(this.jpjInfo.szPDLDate.Substring(10).Trim());
			this.lstjpjInfo.Items[1].SubItems.Add(this.jpjInfo.szGDLDate.Substring(0,10).Trim());
			this.lstjpjInfo.Items[1].SubItems.Add(this.jpjInfo.szGDLDate.Substring(10).Trim());
			this.lstjpjInfo.Items[2].SubItems.Add(this.jpjInfo.szPSVDate.Substring(0,10).Trim());
			this.lstjpjInfo.Items[2].SubItems.Add(this.jpjInfo.szPSVDate.Substring(10).Trim());
			this.lstjpjInfo.Items[3].SubItems.Add(this.jpjInfo.szCDLDate.Substring(0,10).Trim());
			this.lstjpjInfo.Items[3].SubItems.Add(this.jpjInfo.szCDLDate.Substring(10).Trim());

			this.txtOwnerCat.Text=this.jpjInfo.szOwnerCat.Trim();
			this.txtVehClass.Text=this.jpjInfo.szVehicleClass.Trim();
			this.txtHRegNo.Text=this.jpjInfo.szHandiRegNo.Trim();	
		
		}
	}
}
