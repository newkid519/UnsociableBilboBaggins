using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using SekureAppCsharp.Utility;

namespace SekureAppCsharp.JPN_Info
{
	/// <summary>
	/// Summary description for JPNForm.
	/// </summary>
	public class frmJpnInfo : System.Windows.Forms.Form
	{
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.TextBox txtIDNo;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.Label label8;
		private System.Windows.Forms.Label label9;
		private System.Windows.Forms.Label label10;
		private System.Windows.Forms.Label label11;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;
		private System.Windows.Forms.TextBox txtReligion;
		private System.Windows.Forms.TextBox txtBplace;
		private System.Windows.Forms.TextBox txtBDate;
		private System.Windows.Forms.TextBox txtCitizenship;
		private System.Windows.Forms.TextBox txtGender;
		private System.Windows.Forms.TextBox txtIssDate;
		private System.Windows.Forms.TextBox txtName;
		private System.Windows.Forms.TextBox txtAddress;
		private System.Windows.Forms.TextBox txtPostcode;
		private System.Windows.Forms.TextBox txtState;
		private System.Windows.Forms.PictureBox picBox;
		private SekureClass.JPNCARDINFO jpnInfo;

		public frmJpnInfo(SekureClass.JPNCARDINFO jpnInfo)
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
			this.jpnInfo=jpnInfo;
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					
					this.picBox.Dispose();
					components.Dispose();
				}
			}

			
			this.picBox.Dispose();

			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.label1 = new System.Windows.Forms.Label();
			this.txtIDNo = new System.Windows.Forms.TextBox();
			this.txtName = new System.Windows.Forms.TextBox();
			this.label2 = new System.Windows.Forms.Label();
			this.txtAddress = new System.Windows.Forms.TextBox();
			this.label3 = new System.Windows.Forms.Label();
			this.txtPostcode = new System.Windows.Forms.TextBox();
			this.label4 = new System.Windows.Forms.Label();
			this.txtState = new System.Windows.Forms.TextBox();
			this.label5 = new System.Windows.Forms.Label();
			this.txtReligion = new System.Windows.Forms.TextBox();
			this.label6 = new System.Windows.Forms.Label();
			this.txtBplace = new System.Windows.Forms.TextBox();
			this.label7 = new System.Windows.Forms.Label();
			this.txtBDate = new System.Windows.Forms.TextBox();
			this.label8 = new System.Windows.Forms.Label();
			this.txtCitizenship = new System.Windows.Forms.TextBox();
			this.label9 = new System.Windows.Forms.Label();
			this.txtGender = new System.Windows.Forms.TextBox();
			this.label10 = new System.Windows.Forms.Label();
			this.txtIssDate = new System.Windows.Forms.TextBox();
			this.label11 = new System.Windows.Forms.Label();
			this.picBox = new System.Windows.Forms.PictureBox();
			this.SuspendLayout();
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(32, 32);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(40, 23);
			this.label1.TabIndex = 0;
			this.label1.Text = "ID No:";
			// 
			// txtIDNo
			// 
			this.txtIDNo.Location = new System.Drawing.Point(88, 32);
			this.txtIDNo.Name = "txtIDNo";
			this.txtIDNo.ReadOnly = true;
			this.txtIDNo.Size = new System.Drawing.Size(136, 20);
			this.txtIDNo.TabIndex = 1;
			this.txtIDNo.Text = "";
			// 
			// txtName
			// 
			this.txtName.Location = new System.Drawing.Point(88, 64);
			this.txtName.Name = "txtName";
			this.txtName.ReadOnly = true;
			this.txtName.Size = new System.Drawing.Size(136, 20);
			this.txtName.TabIndex = 3;
			this.txtName.Text = "";
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(32, 64);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(40, 23);
			this.label2.TabIndex = 2;
			this.label2.Text = "Name:";
			// 
			// txtAddress
			// 
			this.txtAddress.Location = new System.Drawing.Point(88, 96);
			this.txtAddress.Multiline = true;
			this.txtAddress.Name = "txtAddress";
			this.txtAddress.ReadOnly = true;
			this.txtAddress.Size = new System.Drawing.Size(136, 64);
			this.txtAddress.TabIndex = 5;
			this.txtAddress.Text = "";
			// 
			// label3
			// 
			this.label3.Location = new System.Drawing.Point(32, 96);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(56, 23);
			this.label3.TabIndex = 4;
			this.label3.Text = "Address:";
			// 
			// txtPostcode
			// 
			this.txtPostcode.Location = new System.Drawing.Point(88, 168);
			this.txtPostcode.Name = "txtPostcode";
			this.txtPostcode.ReadOnly = true;
			this.txtPostcode.Size = new System.Drawing.Size(136, 20);
			this.txtPostcode.TabIndex = 7;
			this.txtPostcode.Text = "";
			// 
			// label4
			// 
			this.label4.Location = new System.Drawing.Point(32, 168);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(56, 23);
			this.label4.TabIndex = 6;
			this.label4.Text = "Postcode:";
			// 
			// txtState
			// 
			this.txtState.Location = new System.Drawing.Point(88, 200);
			this.txtState.Name = "txtState";
			this.txtState.ReadOnly = true;
			this.txtState.Size = new System.Drawing.Size(136, 20);
			this.txtState.TabIndex = 9;
			this.txtState.Text = "";
			// 
			// label5
			// 
			this.label5.Location = new System.Drawing.Point(32, 200);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(40, 23);
			this.label5.TabIndex = 8;
			this.label5.Text = "State:";
			// 
			// txtReligion
			// 
			this.txtReligion.Location = new System.Drawing.Point(320, 168);
			this.txtReligion.Name = "txtReligion";
			this.txtReligion.ReadOnly = true;
			this.txtReligion.Size = new System.Drawing.Size(136, 20);
			this.txtReligion.TabIndex = 19;
			this.txtReligion.Text = "";
			// 
			// label6
			// 
			this.label6.Location = new System.Drawing.Point(240, 168);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(48, 23);
			this.label6.TabIndex = 18;
			this.label6.Text = "Religion:";
			// 
			// txtBplace
			// 
			this.txtBplace.Location = new System.Drawing.Point(320, 136);
			this.txtBplace.Name = "txtBplace";
			this.txtBplace.ReadOnly = true;
			this.txtBplace.Size = new System.Drawing.Size(136, 20);
			this.txtBplace.TabIndex = 17;
			this.txtBplace.Text = "";
			// 
			// label7
			// 
			this.label7.Location = new System.Drawing.Point(240, 136);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(64, 23);
			this.label7.TabIndex = 16;
			this.label7.Text = "Birth Place:";
			// 
			// txtBDate
			// 
			this.txtBDate.Location = new System.Drawing.Point(320, 104);
			this.txtBDate.Multiline = true;
			this.txtBDate.Name = "txtBDate";
			this.txtBDate.ReadOnly = true;
			this.txtBDate.Size = new System.Drawing.Size(136, 24);
			this.txtBDate.TabIndex = 15;
			this.txtBDate.Text = "";
			// 
			// label8
			// 
			this.label8.Location = new System.Drawing.Point(240, 104);
			this.label8.Name = "label8";
			this.label8.Size = new System.Drawing.Size(64, 23);
			this.label8.TabIndex = 14;
			this.label8.Text = "Birth Date:";
			// 
			// txtCitizenship
			// 
			this.txtCitizenship.Location = new System.Drawing.Point(320, 72);
			this.txtCitizenship.Name = "txtCitizenship";
			this.txtCitizenship.ReadOnly = true;
			this.txtCitizenship.Size = new System.Drawing.Size(136, 20);
			this.txtCitizenship.TabIndex = 13;
			this.txtCitizenship.Text = "";
			// 
			// label9
			// 
			this.label9.Location = new System.Drawing.Point(240, 72);
			this.label9.Name = "label9";
			this.label9.Size = new System.Drawing.Size(64, 23);
			this.label9.TabIndex = 12;
			this.label9.Text = "Citizenship:";
			// 
			// txtGender
			// 
			this.txtGender.Location = new System.Drawing.Point(320, 32);
			this.txtGender.Name = "txtGender";
			this.txtGender.ReadOnly = true;
			this.txtGender.Size = new System.Drawing.Size(32, 20);
			this.txtGender.TabIndex = 11;
			this.txtGender.Text = "";
			// 
			// label10
			// 
			this.label10.Location = new System.Drawing.Point(240, 32);
			this.label10.Name = "label10";
			this.label10.Size = new System.Drawing.Size(48, 23);
			this.label10.TabIndex = 10;
			this.label10.Text = "Gender:";
			// 
			// txtIssDate
			// 
			this.txtIssDate.Location = new System.Drawing.Point(320, 200);
			this.txtIssDate.Name = "txtIssDate";
			this.txtIssDate.ReadOnly = true;
			this.txtIssDate.Size = new System.Drawing.Size(136, 20);
			this.txtIssDate.TabIndex = 21;
			this.txtIssDate.Text = "";
			// 
			// label11
			// 
			this.label11.Location = new System.Drawing.Point(240, 200);
			this.label11.Name = "label11";
			this.label11.Size = new System.Drawing.Size(64, 23);
			this.label11.TabIndex = 20;
			this.label11.Text = "Issue Date:";
			// 
			// picBox
			// 
			this.picBox.Location = new System.Drawing.Point(472, 24);
			this.picBox.Name = "picBox";
			this.picBox.Size = new System.Drawing.Size(152, 200);
			this.picBox.TabIndex = 22;
			this.picBox.TabStop = false;
			// 
			// frmJpnInfo
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(640, 238);
			this.Controls.Add(this.picBox);
			this.Controls.Add(this.txtIssDate);
			this.Controls.Add(this.label11);
			this.Controls.Add(this.txtReligion);
			this.Controls.Add(this.label6);
			this.Controls.Add(this.txtBplace);
			this.Controls.Add(this.label7);
			this.Controls.Add(this.txtBDate);
			this.Controls.Add(this.label8);
			this.Controls.Add(this.txtCitizenship);
			this.Controls.Add(this.label9);
			this.Controls.Add(this.txtGender);
			this.Controls.Add(this.label10);
			this.Controls.Add(this.txtState);
			this.Controls.Add(this.label5);
			this.Controls.Add(this.txtPostcode);
			this.Controls.Add(this.label4);
			this.Controls.Add(this.txtAddress);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.txtName);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.txtIDNo);
			this.Controls.Add(this.label1);
			this.Name = "frmJpnInfo";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "JPN Info";
			this.Load += new System.EventHandler(this.frmJpnInfo_Load);
			this.ResumeLayout(false);

		}
		#endregion

		private void frmJpnInfo_Load(object sender, System.EventArgs e)
		{
			this.txtIDNo.Text=this.jpnInfo.szIDNo.Trim();
			this.txtName.Text=this.jpnInfo.szGSName.Trim();
			this.txtPostcode.Text=this.jpnInfo.szPostCode.Trim();
			this.txtGender.Text=this.jpnInfo.szGender.Trim();
			this.txtReligion.Text=this.jpnInfo.szGender.Trim();
			this.txtCitizenship.Text=this.jpnInfo.szCitizenship.Trim();
			this.txtAddress.Text=this.jpnInfo.szAddress1.Trim() + " " + 
								 this.jpnInfo.szAddress2.Trim() + " " +
								 this.jpnInfo.szAddress3.Trim();
			this.txtState.Text=this.jpnInfo.szState.Trim();
			this.txtBDate.Text=this.jpnInfo.szBirthDate.Trim();
			this.txtBplace.Text=this.jpnInfo.szBirthPlace.Trim();
			this.txtCitizenship.Text=this.jpnInfo.szCitizenship.Trim();
			this.txtIssDate.Text=this.jpnInfo.szIssueDate.Trim();
			//picBox.Image.FromFile("C:\\Photo.jpg");
			picBox.Image=Image.FromFile("C:\\Photo.jpg");
			//this.Update();

		}
	}
}
