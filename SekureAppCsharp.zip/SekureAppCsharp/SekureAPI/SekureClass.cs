/******************************************************************
/**
/**	File: SEKURE.H
/**	Copyright (C) 2001 Tricubes Computers SDN BHD
/**	Created:	July 12th, 2001
/**	Note: This file contains the standard function prototypes and
/**	data structure for Sekure API
/**
///**	History:
///**
///** Error code checking, proper error handling, Bug fixing,
///** Function pointer handling, dynamic loading & unloading, 
///** process flags function calling morethan one time,
///** Non-repeated ResetCard etc modified by Magesh 
///** Supports : 1.0, 1.5, 2.0 USB/Serial, TCR30
///** Released on: 16-Aug-2007
///** Release ver: 3.0.0.8
///*****************************************************************
///** Version     Date			Modified By		Description
///*****************************************************************
///** 3.0.0.9		17-Aug-2007		Magesh			Clear Capture fail flag when verification in process
///** 3.0.1.0		24-Sep-2007		Magesh			Introducing licensing verification
///** 3.0.1.1		19-Oct-2007		Magesh			Allignment, comments, additional return codes
///** 3.0.1.1		22-Oct-2007		Magesh			comments, additional return codes
///** 3.0.1.1		26-Oct-2007		Magesh			comments, additional new return codes
///** 3.0.0.9		17-Aug-2007		Hanggara		Ported Sekure.h to C# VS-2003
///** 3.0.1.1		12-Nov-2007		Deen			Updated API's and Comments
///** 3.0.1.3		26-Feb-2008 	Deen			Updated API's and Comments
///** 3.0.1.3		26-Feb-2008		Magesh			Added SCRSetPTS function to support non-mykad
///**												Note: CTAPI30.DLL Modified to support non-MyKad Ver 
///**												Check the Version CTAPI30.DLL
///** 3.0.1.4		03-Apr-2008		Magesh			Added SCRResetSAM function to support Sekure-SAM
///** 3.0.1.5		14-Apr-2008		Magesh			Finalized and Tested
///**												Note: SDK Released before 14-Apr-2008 will not work
///**												with this new release, please use License.Dat and new License Key
///**												issued by Tricubes
///** 3.0.1.6		02-Jun-2008		Magesh			Found BUG in Windows NT /95 / 98: Cannot work
///**												Modified to Support Windows NT / 95 / 98
///** 3.0.1.7		05-Jun-2008		Magesh			Product Validation
///**												Note: SDK Released before 05-Jun-2008 will not work
///**												with this new release, please use License.Dat and new License Key
///**												issued by Tricubes with this release
///** 3.0.1.8		10-Jun-2008		Magesh			Tested and Released. Added two return codes for more reference
///** 3.0.1.9		22-Aug-2008		Deen			Implemented New API to support Sekure 3.0
///** 3.0.2.0		17-Sep-2008		Deen			Implemented New APIs to support Sekure 3.0
///**												Introduced new return values for more references
///**               24-Sep-2008     Deen            Modified the SCRGetFingerImage API declaration
///**                                               Introduce two new return values NO_IMAGE_AVAILABLE and NOT_ENOUGH_MEMORY
///**				26-Sep-2008		Deen			Added the declaration of SCRDisableFingerImage API	

///********************************************************************/


using System;
using System.Runtime.InteropServices;

namespace SekureAppCsharp.Utility
{
	/// <summary>
	/// Summary description for SekureClass.
    /// </summary>
	public class SekureClass
	{
		//constants
		//general
		public const int OK = 0;
		public const int FAIL = 1;
		public const int TIMEOUT = 2;
		public const int CTAPI_NOT_INITIALIZED = 4;
		//License Verification General return codes
		public const int LICENSE_NOT_VERIFIED = -101;
		public const int LICENSE_KEY_INVALID = -102;
		public const int LICENSE_DATA_MISSMATCH = -103;
		public const int LICENSE_DATA_CORRUPTED = -104;
		public const int LICENSE_NO_DATA_AVAILABLE = -105;
		public const int LICENSE_SYSTEM_TIME_TAMPERED = -106;
		public const int LICENSE_EXPIRED = -107;
		public const int LICENSE_SYSTEM_TIME_TAMPERED_2 = -108;
		public const int LICENSE_SDK_TAMPERED = -109;
		public const int LICENSE_VERIFICATION_FAIL = -110;
		public const int LICENSE_ALREADY_VERIFIED = -111;
		public const int INVALID_LICENSE_MODULE = -112;
		public const int INVALID_DYNAMIC_KEY_FAIL = -114;
		public const int INVALID_DYNAMIC_ID1_FAIL = -115;
		public const int INVALID_INSTALL_SDK = -116;
		public const int INVALID_DYNAMIC_KEY_WRITE_FAIL = -117;
		public const int INVALID_DYNAMIC_ID2_FAIL = -118;
		public const int INVALID_DYNAMIC_ID3_FAIL = -119;
		public const int INVALID_DYNAMIC_ID4_FAIL = -120;
        //the folloing symbolic const is added for more reference
        //Date: 10-06-2008
        public const int LICENSE_MEMORY_CORRUPTED =	-121; /* License memory corrupted */
        //the folloing symbolic const is modified because of overlapping
        //Date: 10-06-2008
        public const int INVALID_LICENSE_FILE = -122; /* Not a Valid Sekure SDK License file */
        //the folloing symbolic const is added for more reference for Sekure 3.0
        //Date: 25-08-2008
        public const int INVALID_ROW_COLUMN = -123; /* Invalid Row,column Value for SCRGetFingerImage API */
        public const int FINGER_IMAGE_MEMORY_CORRUPTED = -124; /* Memory corrupted */
        //Date: 17-09-2008	
        //Start
        public const int CREATE_FILE_ERROR	= -125; /* Unable to create File */ 
        public const int WRITE_FILE_ERROR =	-126; /* Unable to Write in to File */
        public const int INVALID_PARAMETER_1 = -127; /* Invalid Parameter 1 */
        public const int INVALID_PARAMETER_2 = -128; /* Invalid Parameter 2 */
        public const int INVALID_PARAMETER_3 = -129; /* Invalid Parameter 3 */
        public const int INVALID_PARAMETER_4 = -131;/* Invalid Parameter 4 */
        //End
        //Date: 24-09-2008
        //Start
        public const int NO_IMAGE_AVAILABLE = -132 ; /* Finger Print Image Not Available */
        public const int NOT_ENOUGH_MEMORY = -133 ;  /* Not Enough Memory */
        //End

        /******************************************************************************/
        //SAM General return codes
        /******************************************************************************/
        public const int INVALID_SAM_ID = -130; /*Invalid SAM slot ID */

		/******************************************************************************/
		/*MyKad/Smart Card API's General return codes
		'******************************************************************************/
		
		/*---------------------------
		'SW1 SW2         Description
		'---------------------------
		'0   0           Error in CTAPI
		'45  0           No Parameter Expected
		'96  0           No Parameter Expected
		'96  1           Parameter Expected
		'96  2           No Challenge Expected
		'96  3           Challenge Waiting
		'96  4           Not Expecting a Response
		'96  5           Expecting a Response
		'96  6           Failed / Bad Response
		'96  7           No Data Waiting
		'96  8           Data Waiting
		'96  9           Not Expecting Data
		'96  A           Expecting Data
		'96  B           Bad Xlp
		'96  C           Bad Xlc
		'96  D           Bad Xle
		'96  14          Challenge Failed
		'96  15          Card Blocked
		'96  15          Card Blocked
		'60  xx          Null, Reset Time Work Waiting Time
		'67  xx          Bad Lc
		'6B  xx          Bad P1/P2
		'6D  xx          Bad Ins
		'6E  xx          Bad Cls (SW2 other than 00)
		'6F  xx          General Error
		'91  00          Purse Balance Error Insuf / Exceeded
		'91  02          Replace Purse Balance Error
		'92  02          Write/Memory failure
		'98  04          Access Authorisation Not Fullfilled
		'98  06          Access Authorisation in Debit Not Fullfilled
		'98  20          No Temporary transaction Key
		'6C  40          Wrong Length
		'6C  xx          Buffer Exceeded
		'6A  80          Incorrect Parameter
		'6A  82          File Not Found
		'6A  83          Record Not Found
		'6A  84          Not enough memory
		'6A  88          Key selection Error
		'69  00          No Successful Transaction
		'69  81          Cannot select File
		'69  82          Access Condition not Fullfilled
		'69  83          Secret code locked
		'69  85          No currently selected EF
		'65  81          Write Problem
		'64  A1          Card Not Inserted
		'64  A2          Reset Error
		'64  A8          CheckSum Error
		'63  00          Authentication Failed
		'63  C0/C1/C2/C3/C4/C5/C6            Incorrect Secret Code
		'62  A3          Unsupported protocol error
		'62  A5          (if no Card) Card Removed / (if Card) Damaged or Invalid Card
		'62  A7          (if no Card) Card Removed / (if Card) Damaged or Invalid Card
		'62  81          Invalid IADF
		'62  83          Invalid DF
		'62  84          File Descriptor Error
		'---------------------------
		'*/
		public const int GENERAL_ERROR_1 = 1;                             //Enable Debug Log to know the actual error*/
		public const int GENERAL_ERROR_2 = 2;                              //Enable Debug Log to know the actual error*/
		public const int CARD_REMOVED = 3;
		public const int DAMAGE_INVALID_CARD = 4;                        //Return code SW1 , SW2     62,A7 with Card inside
		/******************************************************************************/

		//Biometrics Device General return codes
		/******************************************************************************/
		//Finger Status code passed in Callback function (or)
		//codes in VerificationResult.nFingerStatus structure member
		public const int BSP_FINGER_OK = 0;
		public const int RIGHT_FINGER = 3;
		public const int LEFT_FINGER = 4;
		public const int BSP_MOVE_UP = -1;
		public const int BSP_MOVE_DOWN = -2;
		public const int BSP_MOVE_LEFT = -3;
		public const int BSP_MOVE_RIGHT = -4;
		public const int BSP_MOVE_PRESS_HARDER = -5;
		public const int BSP_BAD_QUALITY = -6;
		public const int BSP_NO_FINGER = -7;
		public const int BSP_RET_DETECTED_TRACE = -8;
		public const int BSP_RET_NO_DEVICE = -9;
		//MyKad Biometrics Verification API's return codes
		//Synchronized Biometrics Verification API's return code
		//SCRVerifyExternalBio
		public const int BIO_MATCH_OK = 0;                                    //Match OK and terminated success */
		public const int BIO_VERIFY_PROCESS_SUCCESS = -100;
		public const int BIO_VERIFY_PROCESS_SUCCESS_SCR_INIT_FAILED = -80;

		public const int READER_FAILED = -67;
		public const int BIO_INIT_FAILED = -68;
		public const int BIO_PROCESS_FAILED = -69;
		public const int BIO_VERIFY_FAILED = -71;
		public const int BIO_MATCH_FAILED = -72;

		public const int BIO_CAPTURE_FAILED = -73;

		public const int BIO_INIT_FAILED_SCR_INIT_FAILED = -74;
		public const int BIO_PROCESS_FAILED_SCR_INIT_FAILED = -75;
		public const int BIO_VERIFY_FAILED_SCR_INIT_FAILED = -76;
		public const int BIO_MATCH_FAILED_SCR_INIT_FAILED = -77;
		public const int BIO_CAPTURE_FAILED_SCR_INIT_FAILED = -78;
		public const int BIO_MATCH_OK_SCR_INIT_FAILED = -79;

		public const int BIO_ENROLL_SUCCESS = -81;
		public const int BIO_ENROLL_FAILED = -82;
		public const int BIO_NOT_ENROLLED = -83;
		public const int BIO_ENROLL_SUCCESS_SCR_INIT_FAILED = -84;
		public const int BIO_ENROLL_FAILED_SCR_INIT_FAILED = -85;
		public const int BIO_VERIFY_NONMYKAD_SUCCESS_SCR_INIT_FAILED = -86;
		public const int BIO_VERIFY_NONMYKAD_FAILED_SCR_INIT_FAILED = -87;
		public const int BIO_VERIFY_NONMYKAD_SUCCESS = -88;
		public const int BIO_VERIFY_NONMYKAD_FAILED = -89;

		public const int BIO_PARAMETER_INVALID = -90;

		public const int BIO_INITIALIZING = -91;
		public const int BIO_FINGER_STATUS = -92;
		public const int BIO_ENROLL_CAPTURING = -93;
		public const int BIO_VERIFY_CAPTURING = -94;
		public const int BIO_VERIFYING = -95;
		public const int FIRST_FINGER = 10;
		public const int SECOND_FINGER = 11;

		[StructLayout(LayoutKind.Sequential)]
		public struct PHOTOIMAGE
		{
			[MarshalAs(UnmanagedType.ByValArray, SizeConst=5000)]public byte[] pImage;
			public int nSize;
		}

		[StructLayout(LayoutKind.Sequential)]
		public struct BIOMETRICDATA
		{
			[MarshalAs(UnmanagedType.ByValArray, SizeConst=5)]public byte[] szLFinger;
			[MarshalAs(UnmanagedType.ByValArray, SizeConst=5)]public byte[] szRFinger;
			[MarshalAs(UnmanagedType.ByValArray, SizeConst=512)]public byte[] szLFingerData;
			[MarshalAs(UnmanagedType.ByValArray, SizeConst=512)]public byte[] szRFingerData;
			public int nRetval;
		}

		[StructLayout(LayoutKind.Sequential)]
		public struct JPNCARDINFO
		{
			[MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst=3)] public string szVerNo;
			[MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst=5)] public string szSize;
			[MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst=152)] public string szOName;
			[MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst=82)] public string szGSName;
			[MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst=42)] public string szKSName;
			[MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst=15)] public string szIDNo;
			[MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst=5)] public string szGender;
			[MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst=10)] public string szOldIdNo;
			[MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst=12)] public string szBirthDate; 
			[MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst=27)] public string szBirthPlace;
			[MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst=12)] public string szIssueDate;
			[MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst=20)] public string szCitizenship;
			[MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst=27)] public string szRace;
			[MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst=13)] public string szRelegion;
			[MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst=3)] public string szEMOrigin;
			[MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst=5)] public string szRJ; 
			[MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst=5)] public string szKT;
			[MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst=13)] public string szOtherID;
			[MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst=5)] public string  szCategory; 			
			[MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst=4)] public string szCardVer_No; 
			[MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst=12)] public string szGCExpDate;
			[MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst=22)] public string szGCH_Nation;
			[MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst=32)] public string szAddress1; 
			[MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst=32)] public string szAddress2;
			[MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst=32)] public string szAddress3;
			[MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst=8)] public string szPostCode;
			[MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst=27)] public string szCity;
			[MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst=32)] public string szState;
			[MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst=12)] public string szSocsoNo;
			[MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst=12)] public string szLocalityCode;
			[MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst=5)] public string szDOR; 
			public int nReturnVal;
		}

		[StructLayout(LayoutKind.Sequential)]
		public struct JPJCARDINFO
		{

			[MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst=3)] public string szVer_no;
			[MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst=5)] public string szSize;
			[MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst=3)] public string szOwnerCat;
			[MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst=14)] public string szLicenceType;
			[MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst=32)] public string szVehicleClass;
			[MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst=8)] public string szPSVClass;
			[MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst=152)] public string szPSVDes;
			[MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst=8)] public string szGDLClass; 
			[MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst=152)] public string szGDLDes;
			[MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst=22)] public string szPDLDate; 
			[MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst=22)] public string szCDLDate;
			[MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst=22)] public string szPSVDate;
			[MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst=22)] public string szGDLDate;
			[MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst=22)] public string szHandiRegNo; 
			[MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst=3)] public string szKejaraPt;
			[MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst=3)] public string szSuspenGenNo;
			[MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst=12)] public string szKejaraPtUpDate;  
			// Suspension Revocation DF2
			[MarshalAsAttribute(UnmanagedType.ByValArray, SizeConst=215)] public byte[] btSuspensionData;
			//court Endorsement DF3
			[MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst=5)] public string szCELicenceType;
			[MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst=12)] public string szCESDate;
			[MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst=42)] public string szCERemarks; 
			// Summon & Receipt details DF4 
			[MarshalAsAttribute(UnmanagedType.ByValArray, SizeConst=455)] public byte[] btSummonData;
			public int nReturnVal;
		}

		[StructLayout(LayoutKind.Sequential)] 
		public struct IDCARDINFO
		{
		 [MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst=3)] public string szVer_No;
		 [MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst=5)] public string szSize; 
		 [MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst=15)] public string szID_No;
		 [MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst=10)] public  string szOld_ID_No; 
		 [MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst=12)] public string szIssueDate;
		 [MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst=13)] public string szOther_ID; 
		 [MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst=5)] public string szCategory; 
		 [MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst=4)] public string szCardVer_No; 
		 [MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst=12)] public string szGC_Exp_Date;
		public int nReturnVal;
		}
		
		[StructLayout(LayoutKind.Sequential)] 
		public struct IMMCARDINFO
		{	//
			[MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst=3)] public string szVer_No;
			[MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst=5)] public string szSize;
			[MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst=14)] public string szPMA;
			[MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst=5)] public string szPMADocType;
			[MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst=12)] public string szPMAExpDate;
			//Singapore 
			[MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst=14)] public string szSPMT;
			[MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst=5)] public string szSPMTDocType;
			[MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst=12)] public string szSPMTExpDate;
			//Burnei 
			[MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst=14)] public string szBPMT;
			[MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst=5)] public string szBPMTDocType;
			[MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst=12)] public string szBPMTExpDate;
			//Reserved 
			[MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst=14)] public string szRPMT;
			[MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst=5)] public string szRPMTDocType;
			[MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst=12)] public string szRPMTExpDate;
			public int nReturnVal;
		}

		[StructLayout(LayoutKind.Sequential)] 
		public struct MEPSINFO
		{
			public double pBalance;
			public int nReturnVal;
		}
        [StructLayout(LayoutKind.Sequential)]
        public struct KKMCARDMYKIDINFO
        {
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst=3)] public string sz_cardVerNo;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst=5)] public string szSize ;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst=27)] public string szContactName;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst=52)] public string szContactAddress ;
            [MarshalAs(UnmanagedType.ByValTStr, SizeConst=23)] public string szContactPhone ;
            public int nReturnVal;
        }

    [StructLayout(LayoutKind.Sequential)] 
        public struct JPNCARDMYKIDINFO
    {
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst=3)] public string sz_cardVerNo ;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst=5)] public string szSize ;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst=17)] public string szBirthCertNum ;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst=15)] public string szKPTNum ;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst=152)] public string szName ;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst=5)] public string szGender ;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst=20)] public string szCitizenship ;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst=33)] public string szBirth_Place ;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst=32)] public string szAddress1 ;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst=32)] public string szAddress2 ;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst=32)] public string szAddress3 ;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst=8)] public string szPostCode ;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst=32)] public string szCity ;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst=32)] public string szState ;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst=17)] public string szFatherReligion ;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst=17)] public string szMotherReligion ;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst=12)] public string szBirth_Date ;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst=9)] public string szBirth_Time ;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst=42)] public string szPlaceBirth1; 
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst=42)] public string szPlaceBirth2 ;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst=12)] public string szReg_Date ;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst=152)] public string szNewName ;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst=32)] public string szNewAddress1 ;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst=32)] public string szNewAddress2 ;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst=32)] public string szNewAddress3 ;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst=8)] public string szNewPostCode ;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst=32)] public string szNewCity ;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst=32)] public string szNewState ;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst=15)] public string szMotherKPTNum ;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst=17)] public string szMotherDocNum ;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst=52)] public string szMotherDocType ;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst=152)] public string szMotherName ;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst=12)] public string szMotherBirth_Date ;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst=52)] public string szMother_Resident ;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst=32)] public string szMotherRace ;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst=15)] public string szFatherKPTNum; 
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst=17)] public string szFatherDocNum ;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst=52)] public string szFatherDocType ;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst=152)] public string szFatherName ;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst=12)] public string szFatherBirth_Date ;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst=25)] public string szFather_Resident ;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst=32)] public string szFatherRace ;
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst=52)] public string szRegLocation ;
        public int nReturnVal;        
    }
		[StructLayout(LayoutKind.Sequential)] 
		public struct VERIFICATIONRESULT
		{
			public short nFingerStatus; // for finger status callback
			public short nBSPStatus; //for BSP process status callback
			public short nMsgProcess; //for msg info status callback
			public short nProcessStatus; //for bio process result
			public short nErrorCode; // to cater error code from bsp function
			public int nRow; //row of image
			public int nCol; //col of image
			[MarshalAs(UnmanagedType.ByValArray, SizeConst=6000)] public byte[] pImage; //Image data
		}

		public SekureClass()
		{
			//
			// TODO: Add constructor logic here
			//
		}
		
		[DllImport("Sekure.dll",EntryPoint="_SCRSetDependentPath@4")]
		public static extern int SCRSetDependentPath(char[] DepPath);
		
		[DllImport("Sekure.dll",EntryPoint="_SCRVerifyLicense@4")]
		public static extern int SCRVerifyLicense(char[] LicenseKey);

		[DllImport("Sekure.dll")]
			public static extern int SCRInit(int dwPortNo);

		[DllImport("Sekure.Dll")]
			public static extern int SCRClose(int dwPortNo);

		[DllImport("Sekure.Dll")]
			public static extern int SCRGetPhotoImage(int dwPortNo, ref PHOTOIMAGE phImage);

		[DllImport("Sekure.Dll")]
			public static extern int SCRGetJPNCardInfo(int dwPortNo,  ref JPNCARDINFO  jpnInfo);

		[DllImport("Sekure.Dll")]
			public static extern int SCRGetCardStatus(int dwPortNo);

		[DllImport("Sekure.dll")]
			public static extern int SCRResetCard(int dwPortNo);

		[DllImport("Sekure.dll")]
			public static extern int SCRGetJPJCardInfo(int dwPortNo, ref JPJCARDINFO jpjInfo);

		[DllImport("Sekure.dll")]
			public static extern int SCRGetIdCardInfo(int dwPortNo, ref IDCARDINFO idInfo);

		[DllImport("Sekure.dll")]
			public static extern int SCRVerifyBioCB(int dwPortNo);

		[DllImport("Sekure.dll")]
			public static extern int SCRVerifyBioStatusCB(ref VERIFICATIONRESULT verRes);

		[DllImport("Sekure.dll", EntryPoint="_SCRGetMepsBalance@8")]
			public static extern int SCRGetMEPSBalance(int dwPortNo, ref MEPSINFO mepsInfo);

		[DllImport("Sekure.dll", EntryPoint="_SCRGetIMMCardInfo@8")]
			public static extern int SCRGetIMMInfo(int dwPortNo, ref IMMCARDINFO immInfo);

		[DllImport("Sekure.dll", EntryPoint="_SCRResetCT@4")]
		    public static extern int SCRResetCT(int dwPortNo);

		[DllImport("Sekure.dll", EntryPoint="_SCRSwitchDevice@8")]
		    public static extern int SCRSwitchDevice(int dwPortNo,int deviceNo);

		[DllImport("Sekure.dll",EntryPoint="_SCRGetMinutae@8")]
		    public static extern int SCRGetMinutiae(int dwPortNo,ref BIOMETRICDATA bioData);

        [DllImport("Sekure.dll", EntryPoint = "_SCRSetReaderSpeed@4")]
            public static extern int SCRSetReaderSpeed(int nBaudRate);

        [DllImport("Sekure.dll", EntryPoint = "_SCRSetFValue@4")]
            public static extern int SCRSetFValue(int nFValue);
        //nSamID are as follows
        // 1 - Main Reader Slot
        // 5 - SAM Reader 1
        // 7 - SAM Reader 2
        // 9 - SAM Reader 3
        [DllImport("Sekure.dll", EntryPoint = "_SCRResetSAM@4")]
        public static extern int SCRResetSAM(int nSamID);
        //PTS values can the following
        // 0 - Set default values
        // 1 - Applicable for MyKad and some Smart Cards only (Hard-coded Values)
        // 2 - Applicable for some Smart Cards other than MyKad (based on ATR)
        [DllImport("Sekure.dll", EntryPoint = "_SCRSetPTS@4")]
            public static extern int SCRSetPTS(int nPts);
		//API to Send & Receive APDU command to & from Smart Card (or) Smart Card Reader
		//Parameters:
        //usDestAdd - Destination Address can be 0 / 1 / 4 / 5 / 6 / 7 / 8 / 9 ( APDU Command Sending to )
        // 0 - Main Reader Smart Card
        // 1 - Main Reader Slot
        // 4 - SAM SmartCard 1
        // 5 - SAM Reader 1
        // 6 - SAM SmartCard 2
        // 7 - SAM Reader 2
        // 8 - SAM SmartCard 3
        // 9 - SAM Reader 3
		//usSrcAdd - Source Address ( APDU Command Sending from )
		// 2 - Host ( Application )
		//usCmdLen - APDU Command + data length that stored in pbfCmd
		//pbfCmd - APDU Command + data
		//pusRspLen - Reply APDU / return code length that stored in pbfRsp
		//pbfRsp - reply from Start card / Reader
		//Return Value:
		// 0 - Success
		// 1 - Fail refer "MyKad/Smart Card API's General return codes"
		// LICENSE_NOT_VERIFIED - License not verified
		// INVALID_LICENSE_MODULE - No license to communicate with Smart Card using Sekure SDK
		// 3 - Unable to Reset Smart Card
		
		[DllImport("Sekure.dll",EntryPoint="_SCRExchangeAPDU@28")]
		    public static extern int SCRExchangeAPDU(int dwPortNo ,int usDestAdd,int usSrcAdd , int usCmdLen ,ref byte[] pbfCmd , int[] pusRspLen ,ref byte[] pbfRsp );
        
        /******************************************************************************/
        //General Biometrics Device API's
        /******************************************************************************/
		[DllImport("Sekure.dll",EntryPoint="_SCRInitBiometric@4")]
            public static extern int SCRInitBiometric(int dwPortNo);
		[DllImport("Sekure.dll",EntryPoint="_SCRCloseBiometric@4")]
		    public static extern int SCRCloseBiometric(int dwPortNo);
        [DllImport("Sekure.Dll", EntryPoint = "_SCRTerminateBio@4")]
            public static extern int SCRTerminateBio(int dwPortNo);
		//pFS is NULL -> Callback is disabled
		//pFirstFingerData if not NULL -> 256 bytes will be copied as reference minutiate 1
		//pFirstFingerData if NULL -> returns BIO_PARAMETER_INVALID
		//pSecondFingerData if not NULL -> 256 bytes will be copied as reference minutiate 2
		//pSecondFingerData if NULL -> Will enroll and Verify against pFirstFingerData
		//Return Value:
		//0 - Verification Process Started Successfully
		//1 - Function already in progress (or) Process started
		//other values are GetLastError refer MSDN - Verification process not started
		
		[DllImport("Sekure.dll",EntryPoint="_SCRVerifyNonMyKadBiometricCBEx@24")]
		    public static extern int SCRVerifyNonMyKadBiometricCBEx(int dwPortNo, ref long pFS ,ref byte[] pFirstFingerData, int nFirstFingerLen , ref byte[] pSecondFingerData , int nSecondFingerLen);
		//Asynchronized Biometrics Enrollment API's
		[DllImport("Sekure.dll",EntryPoint="_SCREnrollBiometricCBEx@8")]
		    public static extern int SCREnrollBiometricCBEx(int dwPortNo, ref long pFS);
		//Last Enrolled minutiae will be copied to pData (Application should allocate Memory must be more than 260 array)
		//Call this function immedatly when nProcessStatus == BIO_ENROLL_SUCCESS
		//Return Value:
		//0 - Success (pData will have 256 bytes Enrolled Minutiae, nRspLen will have 256)
		//BIO_NOT_ENROLLED - Enroll API not called
		[DllImport("Sekure.dll",EntryPoint="_SCRGetEnrolledMinutiae@8")]
		    public static extern int SCRGetEnrolledMinutiae(ref byte[] pData, ref int nRspLen);
        //MyKad Biometrics Verification API's
        //Synchronized MyKad Biometrics Verification API's
        [DllImport("Sekure.dll", EntryPoint = "_SCRVerifyBiometric@4")]
            public static extern int SCRVerifyBiometric(int dwPortNo);
        [DllImport("Sekure.dll", EntryPoint = "_SCRVerifyExternalBio@8")]
            public static extern int SCRVerifyExternalBio(int dwPortNo, ref BIOMETRICDATA bioData);
        //Asynchronized MyKad Biometrics Verification API's
        [DllImport("Sekure.dll", EntryPoint = "_SCRVerifyBiometricCB@8")]
            public static extern int SCRVerifyBiometricCB(int dwPortNo, ref long pFS);
        [DllImport("Sekure.dll", EntryPoint = "_SCRVerifyBiometricCBEx@12")]
            public static extern int SCRVerifyBiometricCBEx(int dwPortNo, ref long pFS, ref BIOMETRICDATA bioData);
        [DllImport("Sekure.dll", EntryPoint = "_SCRGetKKMMyKidCardInfo@8")]
            public static extern int SCRGetKKMMyKidCardInfo (int dwPortNo, ref KKMCARDMYKIDINFO kkmMyKidInfo);
        [DllImport("Sekure.dll", EntryPoint = "_SCRGetJPNMyKidCardInfo@8")]
            public static extern int SCRGetJPNMyKidCardInfo (int dwPortNo, ref JPNCARDMYKIDINFO jpnMyKidInfo);
        [DllImport("Sekure.dll", EntryPoint = "_SCRGetJPNMyKidCardInfo2@8")]
            public static extern int SCRGetJPNMyKidCardInfo2(int dwPortNo, ref JPNCARDMYKIDINFO jpnMyKidInfo);
        //API to Set Call Back function
        [DllImport("Sekure.dll", EntryPoint = "_Finger_Status@4")]
            public static extern int Finger_Status(ref long pFS);
         //API's for Sekure 3.0 
        //Call this API to get the finger print raw image.
        //When using Sekure 3.0 and above the row and column value in two different sizes
        //While doing verification row = 200 and column = 128
        //After verification row = 400 and column = 256
        //For Sekure 1.0,1.5 and 2.0 the row and column value will be the following in all times
        //row = 90 column = 64
        //Modified by Deen Ieon Ali 24-09-2008
        //The declaration is modified from
        //[DllImport("Sekure.dll", EntryPoint = "_SCRGetFingerImage@12")]
        //public static extern int SCRGetFingerImage(ref byte[] pBuffer, int nRow, int nCol);
        //to
        [DllImport("Sekure.dll", EntryPoint = "_SCRGetFingerImage@16")]
        public static extern int SCRGetFingerImage(ref byte[] pBuffer, ref int nRow, ref int nCol, ref int nBufferLen);
        //Call this API to convert the raw image data to BMP and write in to specified file
        [DllImport("Sekure.dll", EntryPoint = "_SCRConvertRAWImageToBMP@16")]
        public static extern int SCRConvertRAWImageToBMP(int  nRow, int nCol, ref byte pRawData, string pszFileName);
        //Call this API to draw the finger print image in the specified window
        [DllImport("Sekure.dll", EntryPoint = "_SCRDrawFingerImage@16")]
        public static extern int SCRDrawFingerImage(IntPtr hWnd, int row, int col, ref byte pszRaw);
        //Call this API to disable the Finger Print Image while capture or verification process
        //By Default the finger print image will available
        [DllImport("Sekure.dll", EntryPoint = "_SCRDisableFingerImage@4")]
        public static extern int SCRDisableFingerImage(bool bGrabImage);
    }
}
